<?php

require_once 'db/mysql.php';

$db = new Db_Mysql(array(
    'dbname' => 'shift_planning_test',
    'username' => null,
    'password' => null,
    'host' => 'localhost'
));


var_dump($db);