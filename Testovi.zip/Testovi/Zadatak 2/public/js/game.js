var WaysGame = function(){
    //main variables
    this.clicks = 0;
}


WaysGame.prototype.startGame = function(){
    //We start game here
}

WaysGame.prototype.endGame = function(){
    //We end game here
}

WaysGame.prototype.calculatePosition = function(){
    //Calculate where you can click next
}

//This is basic skeleton of game. You are supposed to continue from this point.