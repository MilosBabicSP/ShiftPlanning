<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Zadatak 2</title>
        <script type="text/javascript" src="public/js/jquery.js"></script>
    </head>
    <body>
        <!-- Here goes content -->
    </body>
</html>

