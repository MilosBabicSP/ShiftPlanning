<?php
class Functions {
    
    private function low(){
        
    }
    
    private function medium(){
        
    }
    
    private function high(){
        
    }
    
    private function getPassword($type, $len, $specChar = false){
        switch ($type){
            default :
                $this->low($len, $specChar);
        }
    }
    
    
    
    /**
     *
     * @var Functions
     */
    protected static $_instance;

    /**
     *
     * @return Functions
     */
    public static function getInstance() {
        if (null == self::$_instance) {
            self::$_instance = new Functions();
        }
        return self::$_instance;
    }
}