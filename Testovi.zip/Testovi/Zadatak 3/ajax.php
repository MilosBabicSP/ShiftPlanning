<?php
    include 'class/functions.php';
    
    echo Functions::getInstance()->getPassword($type, $len, $specChar);
?>